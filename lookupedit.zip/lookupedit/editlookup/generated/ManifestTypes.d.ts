/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    lookupFieldId: ComponentFramework.PropertyTypes.LookupProperty;
    parentEntitySchemaName: ComponentFramework.PropertyTypes.StringProperty;
    parentRecordId: ComponentFramework.PropertyTypes.StringProperty;
    parentEntityBindSchema: ComponentFramework.PropertyTypes.StringProperty;
    lookupEntitySchemaName: ComponentFramework.PropertyTypes.StringProperty;
    lookupEntityNameColumnSchema: ComponentFramework.PropertyTypes.StringProperty;
    columnsOfLookupEntity: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    lookupFieldId?: ComponentFramework.LookupValue[];
    parentRecordId?: string;
}
