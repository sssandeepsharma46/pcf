export const fetchAccountRecord = async (
    webAPI: ComponentFramework.WebApi,
    accountId: string
):Promise<{name:string; phone:string; accountid:string} | null> =>
{
    try{
        const response = await webAPI.retrieveRecord("account", accountId, "?$select=name,telephone1");
        return{
            name:response.name,
            phone:response.telephone1,
            accountid:response.accountid
        };
    } catch(error){
        console.error("Error fetching Account record:",error);
        return null;
    }
};