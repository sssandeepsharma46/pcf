import { error } from "console";
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { fetchAccountRecord } from "./helper/dataversehelper";

interface Account {
    accountid: string;
    name: string;
    phone?: string;
}

export class dnlbaccountdetails implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    //declare the properties
    private _container :HTMLDivElement;
    private _accountNameInput : HTMLInputElement;
    private _accountPhoneInput: HTMLInputElement;
    private _editButton: HTMLButtonElement;
    private _saveButton: HTMLButtonElement;
    private _selectAccountButton: HTMLButtonElement;
    private _context: ComponentFramework.Context<IInputs>;
    private _accountId : string | null;

    private _lookupListContainer: HTMLDivElement;
    private _accountSearchInput: HTMLInputElement;
    private _accountsList: HTMLUListElement;
    private lookupListContainer: HTMLDivElement | null = null;
    private _notifyOutputChanged: ()=>void;
    /**
     * Empty constructor.
     */
    constructor()
    {

    }

    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */
    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container:HTMLDivElement): void
    {
        // Add control initialization code
        this._context = context;
        this._container = container;
        this._notifyOutputChanged = notifyOutputChanged;
        this._accountId = context.parameters.parentcustomerid.raw && context.parameters.parentcustomerid.raw.length > 0 ? context.parameters.parentcustomerid.raw[0].id : null;

        this._accountNameInput = document.createElement("input");
        this._accountPhoneInput = document.createElement("input");
        this._editButton = document.createElement("button");
        this._saveButton = document.createElement("button");
        this._selectAccountButton = document.createElement("button");

        this._editButton.innerText = "Edit";
        this._saveButton.innerText = "Save";
        this._saveButton.style.display="none";
        this._selectAccountButton.innerText = "Select Account";

        this._accountNameInput.classList.add("account-details-card", "input");
        this._accountPhoneInput.classList.add("account-details-card", "input");
        this._editButton.classList.add("account-details-card", "button", "edit-button");
        this._saveButton.classList.add("account-details-card", "button", "save-button");
        this._selectAccountButton.classList.add("account-details-card", "select-account-button", "button");

        
        this._editButton.addEventListener("click",this.onEdit.bind(this));
        this._saveButton.addEventListener("click",this.onSave.bind(this));
        this._selectAccountButton.addEventListener("click",this.onSelectAccount.bind(this));

        this._container.appendChild(this._accountNameInput);
        this._container.appendChild(this._accountPhoneInput);
        this._container.appendChild(this._editButton);
        this._container.appendChild(this._saveButton);
        this._container.appendChild(this._selectAccountButton);
        this.renderAccountDetails();

    }

    private async renderAccountDetails(): Promise<void> {
        if (this._accountId) {
            // If accountId is present, fetch account details
            const account = await fetchAccountRecord(this._context.webAPI, this._accountId);
            if (account) {
                this._accountNameInput.value = account.name;
                this._accountPhoneInput.value = account.phone; // Make sure phone field name matches your field in Dataverse
            }
        
            // Disable the input fields as we are viewing the details
            this._accountNameInput.disabled = true;
            this._accountPhoneInput.disabled = true;
        
            // Show 'Edit' button and hide 'Save' and 'Select Account' buttons
            this._editButton.style.display = "inline";
            this._saveButton.style.display = "none";
            this._selectAccountButton.style.display = "none";
        } else {
            // If no accountId, display input fields for creating a new account or selecting an account
            this._accountNameInput.value = "";
            this._accountPhoneInput.value = "";
            this._accountNameInput.disabled = false;
            this._accountPhoneInput.disabled = false;
        
            // Show 'Select Account' button and hide 'Edit' and 'Save' buttons
            this._editButton.style.display = "none";
            this._saveButton.style.display = "none";
            this._selectAccountButton.style.display = "inline";
        
            // Add an event listener for the Select Account button
            this._selectAccountButton.addEventListener("click", this.onSelectAccount.bind(this));
        }
    }

    private onEdit() : void{
        this._accountNameInput.disabled = false;
        this._accountPhoneInput.disabled = false;
        this._editButton.style.display = "none";
        this._saveButton.style.display = "inline";
    }

    private async onSave() : Promise<void>{
        if(this._accountId){
            try{
                const updateRecord = {
                    name: this._accountNameInput.value,
                    telephone1:this._accountPhoneInput.value,
                };
                await this._context.webAPI.updateRecord("account",this._accountId,updateRecord);
                this._editButton.style.display = "inline";
                this._saveButton.style.display="none";
                this._accountNameInput.disabled = true;
                this._accountPhoneInput.disabled = true;
            }catch(error){
                console.error("Error on Save : ",error);
                return;
            }
        }
    }

    private onSelectAccount(): void {
        // Create a container for the lookup UI if it doesn't already exist
        if (!this.lookupListContainer) {
            this.lookupListContainer = document.createElement("div");
            this.lookupListContainer.classList.add("lookup-container");
    
            // Create the search input field for account search
            this._accountSearchInput = document.createElement("input");
            this._accountSearchInput.type = "text";
            this._accountSearchInput.placeholder = "Search Accounts...";
            this.lookupListContainer.appendChild(this._accountSearchInput);
    
            // Create the list element to display search results
            this._accountsList = document.createElement("ul");
            this._accountsList.classList.add("accounts-list");
            this.lookupListContainer.appendChild(this._accountsList);
    
            // Append the lookup UI to the container
            this._container.appendChild(this.lookupListContainer);
    
            // Add event listener for input to handle search
            this._accountSearchInput.addEventListener("input", this.onSearchAccount.bind(this, this._accountSearchInput, this._accountsList));
        }
    }

    private async onSearchAccount(inputField: HTMLInputElement, resultsList: HTMLUListElement): Promise<void> {
        const searchQuery = inputField.value.trim();
    
        if (searchQuery.length > 2) {
            // Fetch accounts based on search query (replace with actual API call to get accounts from Dataverse)
            const accounts = await this.fetchAccounts(searchQuery);
    
            // Clear previous results
            resultsList.innerHTML = "";
    
            // Display the new search results
            accounts.forEach(account => {
                const listItem = document.createElement("li");
                listItem.textContent = account.name;
                listItem.classList.add("account-item");
    
                // Attach a click event to each account item
                listItem.addEventListener("click", () => this.onAccountSelect(account));
                resultsList.appendChild(listItem);
            });
        }
    }

    private async fetchAccounts(searchQuery: string): Promise<Account[]> {
        const query = `?$filter=startswith(name,'${searchQuery}')`;
        const accounts = await this._context.webAPI.retrieveMultipleRecords("account", query);
    
        return accounts.entities.map(entity => ({
            accountid: entity.accountid,
            name: entity.name,
            phone: entity.telephone1,  // Example, you can modify this if necessary
        }));
    }
    
    private onAccountSelect(account: Account): void {
        // Set the selected account ID
        this._accountId = account.accountid;
    
        // Hide the lookup UI after selection
        if (this.lookupListContainer) {
            this.lookupListContainer.style.display = "none";
        }

        // Update the parentcustomerid field on the Contact record
        this.updateParentCustomerId(account.accountid);
    
        // Render the account details after selection
        this.renderAccountDetails();
        this._notifyOutputChanged();
    }

    private async updateParentCustomerId(accountId: string): Promise<void> {
        try {
            // Get the current Contact record ID from the context (the contact ID that this control is bound to)
            const contactId = this._context.parameters.contactid.raw; // This will give the Contact ID as a string

            if (!contactId) {
                console.error("No Contact ID found");
                return;
            }
    
            // Update the parentcustomerid lookup field
            // Construct the update data for parentcustomerid lookup field
            const updateData = {
                "parentcustomerid_account@odata.bind": `/accounts(${accountId})` // Use the @odata.bind annotation to specify the URL of the related record
            };
    
            // Perform the update using the web API
            await this._context.webAPI.updateRecord("contact", contactId, updateData);
        } catch (error) {
            console.error("Error updating parentcustomerid:", error);
        }
    }

    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void
    {
        // Add code to update control view
        this._context = context;
        this._accountId = context.parameters.parentcustomerid.raw && context.parameters.parentcustomerid.raw.length > 0 ? context.parameters.parentcustomerid.raw[0].id : null;
        this.renderAccountDetails();
    }

    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as "bound" or "output"
     */
    public getOutputs(): IOutputs
    {
        return {};
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void
    {
        // Add code to cleanup control if necessary
        this._editButton.removeEventListener("click",this.onEdit.bind(this));
        this._saveButton.removeEventListener("click",this.onSave.bind(this));
        this._selectAccountButton.removeEventListener("click",this.onSelectAccount.bind(this));
    }
}
