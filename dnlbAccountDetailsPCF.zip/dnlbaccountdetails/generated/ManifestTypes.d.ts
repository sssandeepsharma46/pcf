/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    parentcustomerid: ComponentFramework.PropertyTypes.LookupProperty;
    contactid: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    parentcustomerid?: ComponentFramework.LookupValue[];
    contactid?: string;
}
